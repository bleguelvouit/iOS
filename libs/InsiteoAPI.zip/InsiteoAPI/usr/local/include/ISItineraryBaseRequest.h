//
//  ISItineraryBaseRequest.h
//  LocationAPI
//
//  Created by dev_iphone on 06/01/14.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISItineraryBaseRequest.h
 ISItineraryBaseRequest
 */

#import <Foundation/Foundation.h>

#import "ISPCancelable.h"
#import "ISItinerary.h"
#import "ISPItineraryRequestListener.h"

@class ISItineraryProvider;
@class ISLocation;

/*!
 Class used to represent a base itinerary request.
 */
@interface ISItineraryBaseRequest : NSObject <ISPCancelable>

/*!
 Request itinerary (will be filled by the ISItineraryProvider).
 */
@property (nonatomic, retain) ISItinerary * itinerary;

/*!
 Itinerary request listener.
 */
@property (nonatomic, retain) id<ISPItineraryRequestListener> listener;

/*!
 Boolean used to know if we compute the route for disabled people.
 */
@property (nonatomic, readwrite) Boolean pmr;

/*!
 Method called to recompute the same itinerary request.
 */
- (void)recompute;

@end
