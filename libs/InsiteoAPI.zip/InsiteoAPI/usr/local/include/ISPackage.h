//
//  ISPackage.h
//  CommonAPI
//
//  Created by Baptiste LE GUELVOUIT on 16/11/11.
//  Copyright (c) 2012 INSITEO. All rights reserved.
//

/*!
 @header ISPackage.h
 ISPackage
 */

#import <Foundation/Foundation.h>

#import "ISTypes.h"

/*!
 Class used to represent an INSITEO data package.
 */
@interface ISPackage : NSObject

/*!
 Package type.
 */
@property (nonatomic, readwrite) ISEPackageType packageType;

/*!
 URL to download it.
 */
@property (nonatomic, retain) NSString * fileUrl;

/*!
 Package version.
 */
@property (nonatomic, readwrite) int version;

/*!
 Package zip MD5.
 */
@property (nonatomic, retain) NSString * zipMd5;

/*!
 Package size.
 */
@property (nonatomic, readwrite) int size;

/*!
 Package related site identifier.
 */
@property (nonatomic, readwrite) int siteId;

/*!
 Package related application version.
 */
@property (nonatomic, readwrite) int applicationVersion;

/*!
 Package related language.
 */
@property (nonatomic, retain) NSString * language;

/*!
 Package related INSITEO server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 Package temporary zip path.
 */
@property (nonatomic, retain) NSString * zipPath;

/*!
 Main constructor.
 @param siteId Package related site identifier.
 @param applicationVersion Package related application version.
 @param language Package related language.
 @param zipPath Temporary package zipPath. (Could be nil).
 @param serverType INSITEO server type.
 */
- (id)initWithSiteId:(int)siteId andApplicationVersion:(int)applicationVersion andLanguage:(NSString *)language andZipPath:(NSString *)zipPath andServerType:(ISEServerType)serverType;

/*!
 Static method used to know if the filename parameter corresponds to a known INSITEO package.
 @param filename The filename to test.
 @return The related ISEPackageType. Could be UNKNOWN_PACKAGE.
 */
+ (ISEPackageType)getPackageType:(NSString *)filename;

/*!
 Static method used to know if the directoryName parameter corresponds to a known INSITEO package.
 @param directoryName The wanted package directory name.
 @return The related ISEPackageType. Could be UNKNOWN_PACKAGE.
 */
+ (ISEPackageType)getPackageTypeWithDirectoryName:(NSString *)directoryName;

/*!
 Static method used to get the application directory related to a specific package type.
 @param type Package type to consider.
 @return The related directory path. Could be nil.
 */
+ (NSString *)getDirectoryNameWithType:(ISEPackageType)type;

@end
