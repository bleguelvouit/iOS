//
//  Insiteo.h
//  CommonAPI
//
//  Created by INSITEO on 17/12/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

/*!
 @header Insiteo.h
 Insiteo
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#import "ISPCancelable.h"
#import "ISRODBHelper.h"
#import "ISTypes.h"
#import "ISInsiteoError.h"
#import "ISUser.h"
#import "ISSite.h"

/*!
 Insiteo initialization handler.
 @param error Corresponding initialization error (nil if success).
 @param suggestedSite Most suitable site to start (nil if fail).
 */
typedef void (^InsiteoInitializeHandler)(ISInsiteoError * error, ISUserSite * suggestedSite);

/*!
 Insiteo choose site handler.
 @return Coordinates used to determine the most suitable site to start.
 */
typedef CLLocationCoordinate2D (^InsiteoChooseSiteHandler)(void);

/*!
 Insiteo start site handler.
 @param error Corresponding start error (nil if success).
 @param newPackages All new available packages (nil if fail).
 */
typedef void (^InsiteoStartHandler)(ISInsiteoError * error, NSArray * newPackages);

/*!
 Insiteo update site handler.
 @param error Corresponding update error (nil if success).
 */
typedef void (^InsiteoUpdateHandler)(ISInsiteoError * error);

/*!
 Insiteo update site progress handler.
 @param packageType Current treated package type.
 @param download Boolean used to know if the package is currently downloading or installing.
 @param progress Current package task progress (size for download, files count for install).
 @param total Total size of files count.
 */
typedef void (^InsiteoUpdateProgressHandler)(ISEPackageType packageType, Boolean download, int progress, int total);

@protocol PDebugListener;

/*!
 Class used to provide all generic INSITEO methods.
 */
@interface Insiteo : NSObject

/*!
 A debug listener reference (used to get debug event).
 */
@property (assign) id<PDebugListener> debugListener;

/*!
 Current running task.
 */
@property (nonatomic, retain) id<ISPCancelable> currentTask;

/*!
 Static method used to get the unique instance of the InitProvider.
 @return InitProvider unique instance.
 */
+ (Insiteo *)sharedInstance;

/*!
 Static method that return the current authenticated user.
 @return The current authenticated user (could be nil).
 */
+ (ISUser *)currentUser;

/*!
 Static method that return the current started site.
 @return The current started site (could be nil).
 */
+ (ISSite *)currentSite;

/*!
 Static method used to get the main data directory name from a given server type.
 @param serverType server type.
 @return The related NSString directory name (could be nil).
 */
+ (NSString *)getServerTypeDirectoryName:(ISEServerType)serverType;

/*!
 Static method used to get the server NSString to use in URLs.
 @param serverType Server type.
 @return The related NSString to use in URLs only (could be nil).
 */
+ (NSString *)getServerTypeStringForURL:(ISEServerType)serverType;

/*!
 Static method used to get a server type from its given NSString representation.
 @param serverTypeString INSITEO server type NSString representation.
 @return The related server type.
 */
+ (ISEServerType)getServerTypeFromString:(NSString *)serverTypeString;

/*!
 Static method used to get an NSString representation from a given server type.
 @param serverType Server type.
 @return The related NSString representation (could be nil).
 */
+ (NSString *)getServerTypeToString:(ISEServerType)serverType;

/*!
 Static method used to get a render mode from its given NSString representation.
 @param renderModeString Render mode NSString representation.
 @return The related render mode.
 */
+ (ISERenderMode)getRenderModeFromString:(NSString *)renderModeString;

/*!
 Static method used to get an NSString representation from a given render mode.
 @param renderMode Render mode.
 @return The related NSString representation (could be nil).
 */
+ (NSString *)getRenderModeToString:(ISERenderMode)renderMode;

/*!
 Static method used to get the default INSITEO server URL from a given server type.
 @param server The wanted server type.
 @result The server URL to use.
 */
+ (NSString *)getBaseURL:(ISEServerType)server;

/*!
 Static method used to get the default INSITEO directory path.
 @result The default INSITEO directory path.
 */
+ (NSString *)getRootDirectoryPath;

/*!
 Method used to know if a user is currently authenticated.
 @return
 */
- (Boolean)isAuthenticated;

#pragma mark - Launch

/*!
 Method used to launch the SDK. It will initialize the API and start and update automatically the suggested site.
 @param initializeHandler The API initialization handler to call.
 @param chooseSiteHandler The API choose site handler to call.
 @param startHandler The API start site handler to call.
 @param updateHandler The API update site handler to call.
 @param updateProgressHandler The API update progress handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)launchWithInitializeHandler:(InsiteoInitializeHandler)initializeHandler andChooseSiteHandler:(InsiteoChooseSiteHandler)chooseSiteHandler andStartHandler:(InsiteoStartHandler)startHandler andUpdateHandler:(InsiteoUpdateHandler)updateHandler andUpdateProgressHandler:(InsiteoUpdateProgressHandler)updateProgressHandler;

#pragma mark - Init

/*!
 Method used to initialize the API.
 @param apiKey User api key.
 @param language Wanted initialization language (used to get localized push messages).
 @param analyticsAutoStart Boolean used to know if we can start analytics automatically.
 @param serverType INSITEO server type.
 @param serverUrl Specific server URL to use.
 @param renderMode Wanted render mode.
 @param initializeHandler The API initialization handler to call.
 @param chooseSiteHandler The API choose site handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)initializeWithAPIKey:(NSString *)apiKey andLanguage:(NSString *)language andAnalyticsAutoStart:(Boolean)analyticsAutoStart andServerType:(ISEServerType)serverType andServerUrl:(NSString *)serverUrl andRenderMode:(ISERenderMode)renderMode andInitializeHandler:(InsiteoInitializeHandler)initializeHandler andChooseSiteHandler:(InsiteoChooseSiteHandler)chooseSiteHandler;

/*!
 Method used to initialize the API (serverType = ISEServerTypeProd, serverUrl = nil, renderMode = ISERenderMode2D).
 @param apiKey User api key.
 @param language Wanted initialization language (used to get localized push messages).
 @param analyticsAutoStart Boolean used to know if we can start analytics automatically.
 @param initializeHandler The API initialization handler to call.
 @param chooseSiteHandler The API choose site handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)initializeWithAPIKey:(NSString *)apiKey andLanguage:(NSString *)language andAnalyticsAutoStart:(Boolean)analyticsAutoStart andInitializeHandler:(InsiteoInitializeHandler)initializeHandler andChooseSiteHandler:(InsiteoChooseSiteHandler)chooseSiteHandler;

/*!
 Method used to initialize the API (apiKey get from .plist, language = device language, analyticsAutoStart = YES, serverType = ISEServerTypeProd, serverUrl = nil, renderMode = ISERenderMode2D).
 @param initializeHandler The API initialization handler to call.
 @param chooseSiteHandler The API choose site handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)initializeWithInitializeHandler:(InsiteoInitializeHandler)initializeHandler andChooseSiteHandler:(InsiteoChooseSiteHandler)chooseSiteHandler;

/*!
 Method used to initialize the API (apiKey get from .plist, language = device language, analyticsAutoStart = YES, serverType = ISEServerTypeProd, serverUrl = nil, renderMode = ISERenderMode2D, chooseSiteHandler = nil).
 @param initializeHandler The API initialization handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)initializeWithInitializeHandler:(InsiteoInitializeHandler)initializeHandler;

/*!
 Method used to get the most suitable site from a given lat/long coordinate.
 @param latitude Latitude to use.
 @param longitude Longitude to use.
 @return Most suitable site.
 */
- (ISUserSite *)getBestSiteWithLatitude:(double)latitude andLongitude:(double)longitude;

#pragma mark - Start

/*!
 Method used to start and update a given site.
 @param site The site to start and update.
 @param language The language to use.
 @param applicationVersion The application version to use.
 @param forceDownload Boolean used to know if we force the download of packages even if the application is up to date.
 @param startHandler The API initialization handler to call.
 @param updateHandler The API update handler to call.
 @param updateProgressHandler The API update progress handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)startAndUpdateWithSite:(ISUserSite *)site andLanguage:(NSString *)language andApplicationVersion:(int)applicationVersion andForceDownload:(Boolean)forceDownload andStartHandler:(InsiteoStartHandler)startHandler andUpdateHandler:(InsiteoUpdateHandler)updateHandler andUpdateProgressHandler:(InsiteoUpdateProgressHandler)updateProgressHandler;

/*!
 Method used to start and update a given site (language = most suitable language found, application version = DEFAULT_APPLICATION_VERSION, forceDownload = NO).
 @param site The site to start and update.
 @param startHandler The API initialization handler to call.
 @param updateHandler The API update handler to call.
 @param updateProgressHandler The API update progress handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)startAndUpdateWithSite:(ISUserSite *)site andStartHandler:(InsiteoStartHandler)startHandler andUpdateHandler:(InsiteoUpdateHandler)updateHandler andUpdateProgressHandler:(InsiteoUpdateProgressHandler)updateProgressHandler;

/*!
 Method used to start a given site.
 @param site The site to start.
 @param language The language to use.
 @param applicationVersion The application version to use.
 @param forceDownload Boolean used to know if we force the download of packages even if the application is up to date.
 @param startHandler The API initialization handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)startWithSite:(ISUserSite *)site andLanguage:(NSString *)language andApplicationVersion:(int)applicationVersion andForceDownload:(Boolean)forceDownload andStartHandler:(InsiteoStartHandler)startHandler;

/*!
 Method used to start and update a given site (language = most suitable language found, application version = DEFAULT_APPLICATION_VERSION, forceDownload = NO).
 @param site The site to start and update.
 @param startHandler The API initialization handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)startWithSite:(ISUserSite *)site andStartHandler:(InsiteoStartHandler)startHandler;

#pragma mark - Update

/*!
 Method used to update a given site.
 @param wantedPackages An array of ISPackage that need to be updated.
 @param updateHandler The API update handler to call.
 @param updateProgressHandler The API update progress handler to call.
 @return <b>YES</b> if the given parameters are correct, otherwise <b>NO</b>.
 */
- (Boolean)updateCurrentSiteWithWantedPackages:(NSArray *)wantedPackages andUpdateHandler:(InsiteoUpdateHandler)updateHandler andUpdateProgressHandler:(InsiteoUpdateProgressHandler)updateProgressHandler;

@end
