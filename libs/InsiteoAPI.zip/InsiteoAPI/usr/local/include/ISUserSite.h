//
//  ISUserSite.h
//  CommonAPI
//
//  Created by dev_iphone on 25/03/14.
//  Copyright (c) 2014 Unitag. All rights reserved.
//

/*!
 @header ISUserSite.h
 ISUserSite
 */

#import <Foundation/Foundation.h>

/*!
 1
 */
extern int const DEFAULT_APPLICATION_VERSION;

#import "ISTypes.h"

/*!
 Class used to represent a user INSITEO site.
 */
@interface ISUserSite : NSObject

/*!
 External site identifier.
 */
@property (nonatomic, readwrite) int siteId;

/*!
 Server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 Site label (its name).
 */
@property (nonatomic, retain) NSString * label;

/*!
 Site available languages.
 */
@property (nonatomic, retain) NSArray * languages;

/*!
 Site available versions.
 */
@property (nonatomic, retain) NSArray * versions;

/*!
 Site map server URL.
 */
@property (nonatomic, retain) NSString * mapServer;

/*!
 Site bounding rect top left latitude.
 */
@property (nonatomic, readwrite) double topLeftLatitude;

/*!
 Site bounding rect top left longitudes.
 */
@property (nonatomic, readwrite) double topLeftLongitude;

/*!
 Site bounding rect bottom right latitude.
 */
@property (nonatomic, readwrite) double bottomRightLatitude;

/*!
 Site bounding rect bottom right longitude.
 */
@property (nonatomic, readwrite) double bottomRightLongitude;

/*!
 Site float extra.
 */
@property (nonatomic, readwrite) float fExtra1;

/*!
 Site NSString extra 1.
 */
@property (nonatomic, retain) NSString * extra1;

/*!
 Site NSString extra 2.
 */
@property (nonatomic, retain) NSString * extra2;

/*!
 Site NSString extra 3.
 */
@property (nonatomic, retain) NSString * extra3;

/*!
 Method used to get an NSString represention of all site languages.
 @return NSString represention of all site languages.
 */
- (NSString *)getLanguagesString;

/*!
 Method used to get an NSString represention of all site versions.
 @return NSString represention of all site versions.
 */
- (NSString *)getVersionsString;

/*!
 Method used to know if a lat/long coordinates is inside the site.
 @param latitude Coordinate latitude to check.
 @param longitude Coordinate longitude to check.
 @return <b>YES</b> if the coordinate is inside, otherwise <b>NO</b>.
 */
- (Boolean)isLocationInsideWithLatitude:(double)latitude andLongitude:(double)longitude;

/*!
 Method used to get the minimum distance (in meters) between a lat/long coordinate and the site (4 corners).
 @param latitude Coordinate latitude to use.
 @param longitude Coordinate longitude to use.
 @return The minimum computed distance.
 */
- (double)getMinDistanceWithLatitude:(double)latitude andLongitude:(double)longitude;

@end
