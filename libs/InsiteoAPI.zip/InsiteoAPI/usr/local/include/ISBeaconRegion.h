//
//  ISBeaconRegion.h
//  lbs
//
//  Created by dev on 13/10/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISBeaconRegion.h
 ISBeaconRegion
 */

#import <CoreLocation/CLBeaconRegion.h>

#import "ISBeacon.h"

/*!
 Class used to represent a Beacon Region.
 */
@interface ISBeaconRegion : CLBeaconRegion

/*!
 Beacon Region unique identifier.
 */
@property (nonatomic, retain) NSString * guid;

/*!
 Beacon Region related site identifier.
 */
@property (nonatomic, readwrite) int siteId;

/*!
 Beacon Region related server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 Beacon Region external id (custom attribute).
 */
@property (nonatomic, retain) NSString * externalId;

/*!
 Beacon Region UUID.
 */
@property (nonatomic, retain) NSString * uuid;

/*!
 Beacon Region label.
 */
@property (nonatomic, retain) NSString * label;

/*!
 Beacon Region message.
 */
@property (nonatomic, retain) NSString * message;

/*!
 Beacon Region timer before next notification on entry.
 */
@property (nonatomic, readwrite) float nonRepetitionTimer;

/*!
 Beacon Region related beacons.
 */
@property (nonatomic, retain) NSMutableArray * beacons;

/*!
 Beacon Region proximity.
 */
@property (nonatomic, readwrite) CLProximity proximity;

/*!
 Boolean used to know if Insiteo SDK should present a UILocalNotification on entry.
 */
@property (nonatomic, readwrite) Boolean forceNotification;

/*!
 Beacon Region float extra 1.
 */
@property (nonatomic, readwrite) float fExtra1;

/*!
 Beacon Region String extra 1.
 */
@property (nonatomic, retain) NSString * extra1;

/*!
 Beacon Region String extra 2.
 */
@property (nonatomic, retain) NSString * extra2;

/*!
 Beacon Region String extra 3.
 */
@property (nonatomic, retain) NSString * extra3;

@end
