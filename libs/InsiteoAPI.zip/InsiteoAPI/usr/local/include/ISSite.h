//
//  ISSite.h
//  lbs
//
//  Created by dev_iphone on 19/12/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISSite.h
 ISSite
 */

#import "ISUserSite.h"

#import "ISMap.h"
#import "ISPackage.h"
#import "ISZone.h"

/*!
 Class used to represent an INSITEO launched site.
 */
@interface ISSite : NSObject

/*!
 Related user site.
 */
@property (nonatomic, retain) ISUserSite * userSite;

/*!
 Last start date.
 */
@property (nonatomic, retain) NSDate * lastStartDate;

/*!
 The current root map.
 */
@property (nonatomic, retain) ISMap * mapRoot;

/*!
 All the maps stored in an NSDictionnary (key <=> map identifier : NSNumber).
 */
@property (nonatomic, retain) NSDictionary * maps;

/*!
 All maps zones.
 */
@property (nonatomic, retain) NSDictionary * zones;

/*!
 Application site identifier.
 */
@property (nonatomic, readonly) int siteId;

/*!
 Application language.
 */
@property (nonatomic, retain) NSString * language;

/*!
 Application version.
 */
@property (nonatomic, readwrite) int applicationVersion;

/*!
 Maps resources path.
 */
@property (nonatomic, retain) NSString * mapServer;

/*!
 Boolean used to know if the online initialization succeeded.
 */
@property (readwrite) Boolean isStarted;

/*!
 Method called to get an NSString representing the site version.
 @return Related NSString (ex: @"56/1/fr").
 */
- (NSString *)siteVersionString;

/*!
 Method used to get the site readonly data path.
 */
- (NSString *)getRODataPath;

/*!
 Method used to get the site readwrite data path.
 */
- (NSString *)getRWDataPath;

/*!
 Method used to get the absolute path of a package.
 @param packageType Package type to test.
 @return Absolute package path.
 */
- (NSString *)getPathWithPackageType:(ISEPackageType)packageType;

/*!
 Method used to get current version of a package.
 @param packageType Package type to test.
 @return The current package version.
 */
- (int)getCurrentPackageVersionWithPackageType:(ISEPackageType)packageType;

#pragma mark - MapData

/*!
 Method called to get a specific map with its identifier.
 @param mapId Wanted map identifier.
 @return The related ISMap.
 */
- (ISMap *)getMapWithMapId:(int)mapId;

/*!
 Method called to get a specific zone with its identifier.
 @param zoneId Wanted zone identifier.
 @return The related ISZone.
 */
- (ISZone *)getZoneWithId:(int)zoneId;

/*!
 Method called to get all the zones into a given map.
 @param mapId Wanted map identifier.
 @return An array of ISZone.
 */
- (NSArray *)getZonesWithMapId:(int)mapId;

/*!
 Method used to get all site sorted maps.
 @return An array of sorted ISMap.
 */
- (NSArray *)getSortedMaps;

#pragma mark - Package

/*!
 Method used to check if a package of the given type is already installed.
 @param packageType Package type to test.
 @return <b>YES</b> if it exists, otherwise <b>NO</b>.
 */
- (Boolean)hasPackage:(ISEPackageType)packageType;

@end
