//
//  ISGenericRenderer.h
//  MapAPI
//
//  Created by INSITEO on 29/11/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

/*!
 @header ISGenericRenderer.h
 ISGenericRenderer
 */

#import <Foundation/Foundation.h>

#import "ISPRenderer.h"

/*!
 Class used to represent the generic map renderer we will use.
 */
@interface ISGenericRenderer : NSObject <ISPRenderer>

/*!
 RTO HashMap.
 */
@property (nonatomic, retain) NSMutableDictionary * rtos;

/*!
 The RTO NSArray mutex.
 */
@property (nonatomic, retain) NSLock * rtosLock;

/*!
 Boolean used to know if we moved.
 */
@property (nonatomic, readwrite) Boolean hasMoved;

/*!
 Map view layer.
 */
@property (assign) CCLayer * layer;

/*!
 Main constructor.
 @param rtoClass Related RTO class.
 @param priority Renderer priority.
 */
- (id)initWithRTOClass:(Class)rtoClass andPriority:(int)priority;

/*!
 Method used to get the zone rendering position for a given RTO.
 @param zone Zone to draw in.
 @param rto RTO to draw.
 @param ratio Current rendering ratio.
 @param offset Current rendering offset.
 */
- (CGPoint)getZoneDrawPositionWithZone:(ISZone *)zone andRTO:(id<ISPRTO>)rto andRatio:(float)ratio andOffset:(CGPoint)offset;

/*!
 Method called to remove a RTO with its identifier.
 @param rtoId RTO identifier to remove.
 */
- (void)removeRTOWithId:(int)rtoId;

@end
