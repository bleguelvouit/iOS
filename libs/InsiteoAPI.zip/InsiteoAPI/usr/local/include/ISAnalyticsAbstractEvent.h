//
//  ISAnalyticsAbstractEvent.h
//  CommonAPI
//
//  Created by dev_iphone on 11/02/13.
//
//

/*!
 @header ISAnalyticsAbstractEvent.h
 ISAnalyticsAbstractEvent
 */

#import <Foundation/Foundation.h>

/*!
 @"IS_GUID_PREF_KEY"
 */
extern NSString * const IS_GUID_PREF_KEY;

#import "ISPProtoEventBuilder.h"
#import "ISTypes.h"

/*!
 Class used to represent an analytics abstract event.
 */
@interface ISAnalyticsAbstractEvent : NSObject <ISPProtoEventBuilder>

/*!
 Event timestamp.
 */
@property (nonatomic, readwrite) int64_t timeStamp;

/*!
 Event related GUID.
 */
@property (nonatomic, retain) NSString * userGuid;

/*!
 Event related device GUID.
 */
@property (nonatomic, retain) NSString * deviceGuid;

/*!
 Application bundle identifier.
 */
@property (nonatomic, retain) NSString * bundleIdentifier;

/*!
 Event related server type.
 */
@property (nonatomic, readwrite) ISEServerType serverType;

/*!
 Event related site identifier.
 */
@property (nonatomic, readwrite) int siteId;

@end
