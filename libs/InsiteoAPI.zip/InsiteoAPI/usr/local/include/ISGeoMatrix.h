//
//  ISGeoMatrix.h
//  ARKitDemo
//
//  Created by INSITEO on 02/05/11.
//  Copyright 2011 Zac White. All rights reserved.
//

/*!
 @header ISGeoMatrix.h
 ISGeoMatrix
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/*!
 Class used to handle matrix conversion (meters to lat/long and lat/long to meters).
 */
@interface ISGeoMatrix : NSObject

/*!
 Method used to convert X/Y meters coordinate in lat/long.
 @param x X meters coordinate.
 @param y Y meters coordinate.
 @return Converted lat/long coordinates.
 */
- (CGPoint)toLatLongWithX:(double)x andY:(double)y;

/*!
 Method used to convert lat/long coordinate in meters.
 @param latitude The latitude to convert.
 @param longitude The longitude to convert.
 @return Converted meters coordinates.
 */
- (CGPoint)toMeterWithLatitude:(double)latitude andLongitude:(double)longitude;

/*!
 Method used to convert lat/long span in meters.
 @param latSpan The latitude span to convert.
 @param lonSpan The longitude span to convert.
 @return Converted meters span.
 */
- (CGPoint)spanToMeterFromLatLongWithLatSpan:(double)latSpan andLonSpan:(double)lonSpan;

@end
