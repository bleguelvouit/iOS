//
//  ISAnalyticsManager.h
//  CommonAPI
//
//  Created by dev_iphone on 11/02/13.
//
//

/*!
 @header ISAnalyticsManager.h
 ISAnalyticsManager
 */

#import <Foundation/Foundation.h>

#import "ISAnalyticsGenericEvent.h"
#import "ISAnalyticsLocationEvent.h"
#import "ISPAnalyticsListener.h"

/*!
 Class that manages analytics events.
 */
@interface ISAnalyticsManager : NSObject

/*!
 Analytics listener.
 */
@property (assign) id<ISPAnalyticsListener> listener;

/*!
 Boolean used to know if the analytics manager is started.
 */
@property (nonatomic, readonly) Boolean isStarted;

/*!
 Static method called to get the ISAnalyticsManager unique instance.
 @result The ISAnalyticsManager unique instance.
 */
+ (ISAnalyticsManager *)sharedInstance;

/*!
 Method called to start the ISAnalyticsManager.
 @result Return <b>YES</b> if the ISAnalyticsManager is started, otherwise <b>NO</b>.
 */
- (Boolean)startAnalytics;

/*!
 Method called to stop the ISAnalyticsManager.
 */
- (Boolean)stopAnalytics;

/*!
 Method called to add an analytics generic event.
 @param event The related generic event.
 @result <b>YES</b> if the event was successfully added, otherwise <b>NO</b>.
 */
- (Boolean)addGenericEvent:(ISAnalyticsGenericEvent *)event;

/*!
 Method called to add an analytics location event.
 @param event The related location event.
 @result <b>YES</b> if the event was successfully added, otherwise <b>NO</b>.
 */
- (Boolean)addLocationEvent:(ISAnalyticsLocationEvent *)event;

@end
