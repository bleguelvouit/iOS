//
//  ISPBeaconListener.h
//  lbs
//
//  Created by dev on 13/10/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISPBeaconListener.h
 ISPBeaconListener
 */

#import "ISBeaconRegion.h"
#import "ISBeacon.h"

/*!
 Protocol used to handle Beacon events.
 */
@protocol ISPBeaconListener <NSObject>

#pragma mark - ISBeaconRegion IN/OUT

/*!
 Method called when the user enters in a monitored beaconRegion.
 @param beaconRegion The beacon region the user enters in.
 */
- (void)onEnterBeaconRegion:(ISBeaconRegion *)beaconRegion;

/*!
 Method called when the user exits a monitored beaconRegion.
 @param beaconRegion The ISBeaconRegion the user exits.
 */
- (void)onExitBeaconRegion:(ISBeaconRegion *)beaconRegion;

#pragma mark - ISBeacon IN/OUT

/*!
 Method called when the beacon proximity is reached for an entered beaconRegion.
 @param beacon The beacon with reached proximity.
 @param beaconRegion The beaconRegion associated to the beacon with reached proximity.
 @param proximity The proximity reached.
 */
- (void)onEnterBeacon:(ISBeacon *)beacon forRegion:(ISBeaconRegion *)beaconRegion andProximity:(CLProximity)proximity;

/*!
 Method called when the beacon proximity is not reached anymore for an entered beaconRegion.
 @param beacon The beacon with proximity CLProximityFar or CLProximityUnknown.
 @param beaconRegion The beaconRegion associated to the beacon with the no more reached proximity.
 @param proximity The new proximity.
 */
- (void)onExitBeacon:(ISBeacon *)beacon forRegion:(ISBeaconRegion *)beaconRegion andProximity:(CLProximity)proximity;

@optional

#pragma mark - Beacon Region Notification management

/*!
 Method used to let the ISBeaconProvider managing the UILocalNotification presentation on a beaconRegion entry.
 @param beaconRegion The beacon region the user enters in.
 @return If the ISBeaconProvider should manage the UILocalNotification presentation. YES, by default.
 */
- (BOOL)shouldPresentLocalNotificationOnBeaconRegionEntry:(ISBeaconRegion *)beaconRegion;

/*!
 Method used to get the first ranged beacon on a beaconRegion entry.
 @param beacon The first ranged ISBeacon in region.
 @param beaconRegion The ranged beaconRegion.
 @param error If ranging has failed for region, else nil.
 */
- (void)firstRangedISBeacon:(ISBeacon *)beacon onEntryforRegion:(ISBeaconRegion *)beaconRegion withError:(NSError *)error;

/*!
 Method used to get all ranged beacons in an entered beaconRegion and all beacons which have reached the region proximity.
 @param beacons All ranged beacons, nil if an error occured.
 @param reachedProximityBeacons beacons which have reached the region proximity, nil if an error occured.
 @param beaconRegion The ranged beaconRegion.
 @param error If ranging for the region has failed.
 */
- (void)rangedISBeacons:(NSArray *)beacons andReachedProximityBeacons:(NSArray *)reachedProximityBeacons inRegion:(ISBeaconRegion *)beaconRegion withError:(NSError *)error;

@end