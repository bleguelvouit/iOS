//
//  ISGenericRTO.h
//  InsiteoAPI
//
//  Created by dev_iphone on 16/04/14.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISGenericRTO.h
 ISGenericRTO
 */

#import <Foundation/Foundation.h>

//Intern const used to scroll text
extern int const RTO_LABEL_MAX_LENGTH;

//Intern value used to handle touch move on RTO
extern int const CLICKABLE_RTO_SIZE;

#import "cocos2d.h"
#import "ISPRTO.h"
#import "ISPosition.h"
#import "ISGenericRTONode.h"

@class CC3Billboard;

/*!
 Class which represent a basic RTO object (name + pin image).
 */
@interface ISGenericRTO : CCNode <ISPRTO>

/*!
 RTO position in meters.
 */
@property (nonatomic, retain) ISPosition * metersPosition;

/*!
 Current rendering map.
 */
@property (nonatomic, retain) ISMap * currentMap;

/*!
 Boolean used to know if the RTO is draggable.
 */
@property (nonatomic, readwrite) Boolean draggable;

/*!
 Boolean used to know if the action button was clicked.
 */
@property (nonatomic, readonly) Boolean actionButtonClicked;

/*!
 Related 2D render node.
 */
@property (nonatomic, retain) ISGenericRTONode * rtoNode;

/*!
 Current 3D scene (for 3D rendering only).
 */
@property (nonatomic, assign) CC3Scene * currentScene;

#pragma mark - ISGenericRTONode

/*!
 RTO window background color for normal state.
 */
@property (nonatomic, retain) UIColor * windowBackgroundColorNormal;

/*!
 RTO window background color for highlighted state.
 */
@property (nonatomic, retain) UIColor * windowBackgroundColorHighlighted;

/*!
 RTO action button sprite image path.
 */
@property (nonatomic, retain) NSString * actionImagePath;

/*!
 RTO action button background color for normal state.
 */
@property (nonatomic, retain) UIColor * actionBackgroundColorNormal;

/*!
 RTO action button background color for highlighted state.
 */
@property (nonatomic, retain) UIColor * actionBackgroundColorHighlighted;

/*!
 RTO indicator sprite image path.
 */
@property (nonatomic, retain) NSString * indicatorImagePath;

/*!
 RTO window anchor sprite image path.
 */
@property (nonatomic, retain) NSString * windowAnchorImagePath;

/*!
 RTO marker sprite image path.
 */
@property (nonatomic, retain) NSString * markerImagePath;

/*!
 Main constructor
 @param name RTO displayed name.
 @param label RTO displayed label.
 @param metersPosition RTO position in meters (could be nil in case of zone rendering).
 @param windowDisplayed Boolean used to know if the RTO window has to be displayed.
 @param labelDisplayed Boolean used to know if the RTO label has to be displayed.
 */
- (id)initWithName:(NSString *)name andLabel:(NSString *)label andMetersPosition:(ISPosition *)metersPosition andWindowDisplayed:(Boolean)windowDisplayed andLabelDisplayed:(Boolean)labelDisplayed;

/*!
 Main constructor
 @param name RTO displayed name.
 @param label RTO displayed label.
 @param metersPosition RTO position in meters (could be nil in case of zone rendering).
 @param windowDisplayed Boolean used to know if the RTO window has to be displayed.
 @param labelDisplayed Boolean used to know if the RTO label has to be displayed.
 @param windowBackgroundColorNormal RTO window background color (normal state).
 @param windowBackgroundColorHighlighted RTO window background color (highlighted state).
 @param actionImagePath RTO action image path.
 @param actionBackgroundColorNormal RTO action image background color (normal state).
 @param actionBackgroundColorHighlighted RTO action image background color (highlighted state).
 @param indicatorImagePath RTO indicator image path.
 @param windowAnchorImagePath RTO window anchor image path.
 @param markerImagePath RTO marker image path.
 */
- (id)initWithName:(NSString *)name andLabel:(NSString *)label andMetersPosition:(ISPosition *)metersPosition andWindowDisplayed:(Boolean)windowDisplayed andLabelDisplayed:(Boolean)labelDisplayed andWindowBackgroundColorNormal:(UIColor *)windowBackgroundColorNormal andWindowBackgroundColorHighlighted:(UIColor *)windowBackgroundColorHighlighted andActionImagePath:(NSString *)actionImagePath andActionBackgroundColorNormal:(UIColor *)actionBackgroundColorNormal andActionBackgroundColorHighlighted:(UIColor *)actionBackgroundColorHighlighted andIndicatorImagePath:(NSString *)indicatorImagePath andWindowAnchorImagePath:(NSString *)windowAnchorImagePath andMarkerImagePath:(NSString *)markerImagePath;

/*!
 Method used to set the RTO label as displayed or not.
 @param displayed Boolean used to set the label display state.
 */
- (void)setLabelDisplayed:(Boolean)displayed;

/*!
 Method used to knwo if the RTO toggle its window when the marker was clicked.
 @return <b>YES</b> if you want a toggle action, otherwise <b>NO</b>.
 */
- (Boolean)shouldToggleWindowOnMarkerClicked;

/*!
 Method called to hide the window.
 */
- (void)hideWindow;

/*!
 Method called to show the window.
 */
- (void)showWindow;

/*!
 Method called to toggle RTO appearance.
 */
- (void)toggleWindow;

/*!
 Method called to render the annotation as touched or not.
 @param over <b>YES</b> if you want a touched effect, otherwise <b>NO</b>.
 */
- (void)setOver:(Boolean)over;

/*!
 Method called to render the action button as touched or not.
 @param over <b>YES</b> if you want a touched effect, otherwise <b>NO</b>.
 */
- (void)setOverAction:(Boolean)over;

@end
