//
//  AuthManager.h
//  CommonAPI
//
//  Created by dev_iphone on 25/03/14.
//  Copyright (c) 2014 Unitag. All rights reserved.
//

/*!
 @header AuthManager.h
 AuthManager
 */

#import <Foundation/Foundation.h>

#import "ISTypes.h"
#import "PAuthListener.h"
#import "ISPCancelable.h"

/*!
 Class used to manage INSITEO authentication.
 */
@interface AuthManager : NSObject;

/*!
 Static method used to get the unique instance of the AuthManager.
 @return AuthManager unique instance.
 */
+ (AuthManager *)sharedInstance;

+ (NSString *)hashPasswordWithPassword:(NSString *)password andMail:(NSString *)mail;

#pragma mark - Remote

/*!
 Method used to log in.
 @param mail The user mail.
 @param password The user hash password.
 @param serverType The related server type.
 @param listener The listener to notify.
 */
- (Boolean)loginWithMail:(NSString *)mail andPassword:(NSString *)password andServerType:(ISEServerType)serverType andLanguage:(NSString *)language andListener:(id<PAuthListener>)listener andServerUrl:(NSString *)serverUrl andRenderMode:(ISERenderMode)renderMode;

/*!
 Method used to log out.
 @param serverType The related server type.
 @param listener The listener to notify.
 */
- (Boolean)logoutWithServerType:(ISEServerType)serverType andListener:(id<PAuthListener>)listener;

#pragma mark - Local

- (Boolean)localLoginWithMail:(NSString *)mail andPassword:(NSString *)password andServerType:(ISEServerType)serverType andLanguage:(NSString *)language andListener:(id<PAuthListener>)listener;

@end
