//
//  ISInsiteoError.h
//  CommonAPI
//
//  Created by INSITEO on 28/03/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

/*!
 @header ISInsiteoError.h
 ISInsiteoError
 */

#import <Foundation/Foundation.h>

#import "ISTypes.h"

/*!
 Class used to represent an Insiteo error.
 */
@interface ISInsiteoError : NSObject

/*!
 Error enum code.
 */
@property (nonatomic, readwrite) ISEInsiteoErrorCode code;

/*!
 Error enum reason.
 */
@property (nonatomic, readwrite) ISEInsiteoErrorReason reason;

/*!
 Error message.
 */
@property (nonatomic, retain) NSString * message;

/*!
 Main constructor.
 @param code Error code.
 @param reason Error reason.
 */
- (id)initWithCode:(ISEInsiteoErrorCode)code andReason:(ISEInsiteoErrorReason)reason;

/*!
 Secondary constructor.
 @param code Error code.
 @param reason Error reason.
 @param message Error message.
 */
- (id)initWithCode:(ISEInsiteoErrorCode)code andReason:(ISEInsiteoErrorReason)reason andMessage:(NSString *)message;

/*!
 Static main constructor.
 @param code Error code.
 @param reason Error reason.
 */
+ (id)ISInsiteoErrorWithCode:(ISEInsiteoErrorCode)code andReason:(ISEInsiteoErrorReason)reason;

/*!
 Static main constructor.
 @param code Error code.
 @param reason Error reason.
 @param message Error message.
 */
+ (id)ISInsiteoErrorWithCode:(ISEInsiteoErrorCode)code andReason:(ISEInsiteoErrorReason)reason andMessage:(NSString *)message;

/*!
 Static method used to get the error code NSString representation.
 @param code Error code.
 @return Error code NSString representation.
 */
+ (NSString *)getErrorCodeToString:(ISEInsiteoErrorCode)code;

/*!
 Static method used to get the error reason NSString representation.
 @param reason Error reason.
 @return Error reason NSString representation.
 */
+ (NSString *)getErrorReasonToString:(ISEInsiteoErrorReason)reason;

/*!
 Static method used to get an error reason from a given HTTP status code.
 @param statusCode HTTP status code.
 @return An error reason (default: ISEInsiteoErrorReasonUnknown).
 */
+ (ISEInsiteoErrorReason)getErrorReasonFromStatusCode:(NSInteger)statusCode;

@end
