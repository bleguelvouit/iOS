//
//  ISRODBHelper.h
//  CommonAPI
//
//  Created by Baptiste LE GUELVOUIT on 22/03/12.
//  Copyright (c) 2012 INSITEO. All rights reserved.
//

/*!
 @header ISRODBHelper.h
 ISRODBHelper
 */

#import <Foundation/Foundation.h>
#import <sqlite3.h>

/*!
 Static class used to handle ReadOnly SQLITE requests.
 */
@interface ISRODBHelper : NSObject

@end
