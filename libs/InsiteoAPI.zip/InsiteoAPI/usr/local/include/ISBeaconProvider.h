//
//  BeaconProvider.h
//  LocationAPI
//
//  Created by dev_iphone on 10/12/13.
//  Copyright (c) 2013 INSITEO. All rights reserved.
//

/*!
 @header BeaconProvider.h
 BeaconProvider
 */

#import "ISLocationManager.h"

#import <CoreBluetooth/CoreBluetooth.h>

#import "ISBeaconRegion.h"
#import "ISPBeaconListener.h"

/*!
 Class used to manage Insiteo Beacon and generic iBeacon.
 */
@interface ISBeaconProvider : ISLocationManager <CBCentralManagerDelegate>

#pragma mark - UILocalNotification UserInfo Keys

/*!
 @const @"ISBeaconRegionKeys"
 @discussion This key is used to get Beacon Region information from the default presented UILocalNotification (userInfo).
 */
extern NSString * const ISBeaconRegionKeys;

/*!
 @const @"ISBeaconRegionGuidKey"
 */
extern NSString * const ISBeaconRegionGuidKey;

/*!
 @const @"ISBeaconRegionUUIDKey"
 */
extern NSString * const ISBeaconRegionUUIDKey;

/*!
 @const @"ISBeaconRegionMajorKey"
 */
extern NSString * const ISBeaconRegionMajorKey;

/*!
 @const @"ISBeaconRegionMinorKey"
 */
extern NSString * const ISBeaconRegionMinorKey;

/*!
 @const @"ISBeaconRegionSiteIdKey"
 */
extern NSString * const ISBeaconRegionSiteIdKey;

/*!
 @const @"ISBeaconRegionCustomIdKey"
 */
extern NSString * const ISBeaconRegionCustomIdKey;

/*!
 @const @"ISBeaconRegionLabelKey"
 */
extern NSString * const ISBeaconRegionLabelKey;

/*!
 @const @"ISBeaconRegionMessageKey"
 */
extern NSString * const ISBeaconRegionMessageKey;

/*!
 @const @"ISBeaconRegionFExtra1Key"
 */
extern NSString * const ISBeaconRegionFExtra1Key;

/*!
 @const @"ISBeaconRegionSExtra1Key"
 */
extern NSString * const ISBeaconRegionSExtra1Key;

/*!
 @const @"ISBeaconRegionSExtra2Key"
 */
extern NSString * const ISBeaconRegionSExtra2Key;

/*!
 @const @"ISBeaconRegionSExtra3Key"
 */
extern NSString * const ISBeaconRegionSExtra3Key;

/*!
 ISBeaconProvider singleton instance.
 */
+ (ISBeaconProvider *)sharedInstance;

#pragma mark - Start

/*!
 Method used to start the iBeacon Management.
 @param listener iBeacon events listener.
 */
- (void)startWithListener:(id<ISPBeaconListener>)listener;

#pragma mark - Properties

/*!
 Current monitored beaconRegions.
 */
@property (nonatomic, readonly) NSArray * beaconRegions;

/*!
 Beacon listener.
 */
@property (nonatomic, weak) id<ISPBeaconListener> listener;

@end
