//
//  ISTypes.h
//  lbs
//
//  Created by dev_iphone on 08/07/2014.
//  Copyright (c) 2014 INSITEO. All rights reserved.
//

/*!
 @header ISTypes.h
 ISTypes
 */

#pragma mark - Server type

/*!
 Enum used to handle INSITEO server types.
 @constant ISEServerTypeUnknown Unknown server.
 @constant ISEServerTypeProd Production server.
 @constant ISEServerTypeTest Test server.
 @constant ISEServerTypeDev Development server.
 */
typedef enum {
    ISEServerTypeUnknown = 0,
    ISEServerTypeProd,
    ISEServerTypeTest,
    ISEServerTypeDev
} ISEServerType;

#pragma mark - Package type

/*!
 Enum used to handle INSITEO data packages.
 @constant ISEPackageTypeUnknown Default NULL package type.
 @constant ISEPackageTypeMapData The package that contains Map data such as zoom levels and scales.
 @constant ISEPackageTypeTiles The package that contains Map tiles in .3cm format.
 @constant ISEPackageTypeLocation The package that contains Location data.
 @constant ISEPackageTypeItinerary The package that contains Itinerary data.
 @constant ISEPackageTypeGeofencing The package that contains Geofencing data.
 @constant ISEPackageTypeLrrContent The package that contains low refresh rate catalog content.
 @constant ISEPackageTypeHrrContent The package that contains high refresh rate catalog content.
 @constant ISEPackageTypeFingerprint The package that contains fingerprint configuration files.
 @constant ISEPackageTypeMap3d The package that contains all 3D files.
 @constant ISEPackageTypeExtras The package that contains all extras files.
 */
typedef enum {
    ISEPackageTypeUnknown = 0,
    ISEPackageTypeMapData,
    ISEPackageTypeTiles,
    ISEPackageTypeLocation,
    ISEPackageTypeItinerary,
    ISEPackageTypeGeofencing,
    ISEPackageTypeLrrContent,
    ISEPackageTypeHrrContent,
    ISEPackageTypeFingerprint,
    ISEPackageTypeMap3d,
    ISEPackageTypeExtras
} ISEPackageType;

#pragma mark - Render mode

/*!
 Enum used to handle different map rendering mode.
 @constant ISERenderModeUnknown Unknown render mode.
 @constant ISERenderMode2D 2D rendering.
 @constant ISERenderMode3D 3D rendering.
 */
typedef enum {
    ISERenderModeUnknown = 0,
    ISERenderMode2D,
    ISERenderMode3D
} ISERenderMode;

#pragma mark - Error

/*!
 Enum used to handle INSITEO error codes.
 @constant ISEInsiteoErrorCodeUnknown Unknown error code.
 @constant ISEInsiteoErrorCodeInternal Internal error code.
 @constant ISEInsiteoErrorCodeInitializeApi Error during SDK initialization.
 @constant ISEInsiteoErrorCodeStartSite Error while starting a site.
 @constant ISEInsiteoErrorCodeUpdateSite Error while updating a site.
 @constant ISEInsiteoErrorCodeItinerary Itinerary error.
 @constant ISEInsiteoErrorCodeLocation Location error.
 @constant ISEInsiteoErrorCodeMeetMe MeetMe error.
 */
typedef enum {
    ISEInsiteoErrorCodeUnknown = 0,
    ISEInsiteoErrorCodeInternal,
    ISEInsiteoErrorCodeInitializeApi,
    ISEInsiteoErrorCodeStartSite,
    ISEInsiteoErrorCodeUpdateSite,
    ISEInsiteoErrorCodeItinerary,
    ISEInsiteoErrorCodeLocation,
    ISEInsiteoErrorCodeMeetMe
} ISEInsiteoErrorCode;

/*!
 Enum used to handle INSITEO error reasons.
 @constant ISEInsiteoErrorReasonUnknown Unknown error reason.
 @constant ISEInsiteoErrorReasonInternal Internal error reason.
 @constant ISEInsiteoErrorReasonApiNotInitialized The API needs to be initialized.
 @constant ISEInsiteoErrorReasonConnectivity Connectivity reason.
 @constant ISEInsiteoErrorReasonInvalidFormat An invalid format is used.
 @constant ISEInsiteoErrorReasonDownload The download failed.
 @constant ISEInsiteoErrorReasonInstallation The installation failed.
 @constant ISEInsiteoErrorReasonCancelled Operation cancelled.
 @constant ISEInsiteoErrorReasonComputation Internal computation error.
 @constant ISEInsiteoErrorReasonTimeOut Operation time out.
 @constant ISEInsiteoErrorReasonBadParameters Bad parameters given.
 @constant ISEInsiteoErrorReasonNotFound Resource not found.
 @constant ISEInsiteoErrorReasonBadRequest Bad request.
 @constant ISEInsiteoErrorReasonServer Server reason.
 @constant ISEInsiteoErrorReasonForbidden Operation forbidden.
 */
typedef enum {
    ISEInsiteoErrorReasonUnknown = 0,
    ISEInsiteoErrorReasonInternal,
    ISEInsiteoErrorReasonApiNotInitialized,
    ISEInsiteoErrorReasonConnectivity,
    ISEInsiteoErrorReasonInvalidFormat,
    ISEInsiteoErrorReasonDownload,
    ISEInsiteoErrorReasonInstallation,
    ISEInsiteoErrorReasonCancelled,
    ISEInsiteoErrorReasonComputation,
    ISEInsiteoErrorReasonTimeOut,
    ISEInsiteoErrorReasonBadParameters,
    ISEInsiteoErrorReasonNotFound,
    ISEInsiteoErrorReasonBadRequest,
    ISEInsiteoErrorReasonUnauthorized,
    ISEInsiteoErrorReasonServer,
    ISEInsiteoErrorReasonForbidden
} ISEInsiteoErrorReason;

#pragma mark - Start view mode

/*!
 Enum used to handle map start modes.
 @constant ISEMapStartViewModeUnknown Unknown start mode.
 @constant ISEMapStartViewModeFitToScreen Start map to fit the device screen.
 @constant ISEMapStartViewModePosition Start map on a given position.
 */
typedef enum {
    ISEMapStartViewModeUnknown = 0,
    ISEMapStartViewModeFitToScreen,
    ISEMapStartViewModePosition
} ISEMapStartViewMode;

#pragma mark - Coordinates

/*!
 Enum used to represent a geofencing coordinate mode.
 @constant ISECoordinatesModeXY X/Y coordinate mode (could be meters or pixels etc.).
 @constant ISECoordinatesModeWGS84 GPS coordinate mode.
 */
typedef enum {
    ISECoordinatesModeXY = 0,
    ISECoordinatesModeWGS84 = 1
} ISECoordinatesMode;

#pragma mark - RTO

/*!
 Enum used to handle Renderer management results.
 @constant ISERTOMapIdNone The RTO is never displayed.
 @constant ISERTOMapIdAll The RTO is always displayed.
 */
typedef enum {
    ISERTOMapIdNone = -100,
    ISERTOMapIdAll,
} ISERTOMapId;

/*!
 Enum used to manage touch event handling results.
 @constant ISETouchObjectResultConsume The object consume the event.
 @constant ISETouchObjectResultNotify The object only notify its listeners.
 @constant ISETouchObjectResultConsumeNotify The object consume and notify its listeners.
 @constant ISETouchObjectResultNothing The object do nothing.
 */
typedef enum {
    ISETouchObjectResultConsume,
    ISETouchObjectResultNotify,
    ISETouchObjectResultConsumeNotify,
    ISETouchObjectResultNothing,
} ISETouchObjectResult;

#pragma mark - LBS module

/*!
 Enum used to define location modules.
 @constant ISELbsModuleTypeItinerary Itinerary location module.
 @constant ISELbsModuleTypeMeetMe MeetMe location module.
 @constant ISELbsModuleTypeGeofencing Geofencing location module.
 */
typedef enum {
    ISELbsModuleTypeItinerary,
    ISELbsModuleTypeMeetMe,
    ISELbsModuleTypeGeofencing
} ISELbsModuleType;

#pragma mark - Itinerary

/*!
 Enum used to choose route optimization algorithm.
 @constant ISEOptimizationModeFullRoute 1.
 @constant ISEOptimizationModeEuclidianDistance 2.
 @constant ISEOptimizationModeNearestNeighbourEuclidian 4.
 @constant ISEOptimizationModeNearestNeighbourShortestPath 5.
 @constant ISEOptimizationModeBestMethodPath 7.
 */
typedef enum {
    ISEOptimizationModeFullRoute = 1,
    ISEOptimizationModeEuclidianDistance = 2,
    //	ISEOptimizationModeQuadAreas = 3,
    ISEOptimizationModeNearestNeighbourEuclidian = 4,
    ISEOptimizationModeNearestNeighbourShortestPath = 5,
    //	ISEOptimizationModeHybridPath = 6,
    ISEOptimizationModeBestMethodPath = 7
} ISEOptimizationMode;

#pragma mark - Geofencing

/*!
 Enum used to represent a geofencing zone state.
 @constant ISGeofenceEventTypeUnknown Default value.
 @constant ISGeofenceEventTypeEntering A position is entering a zone (a position was detected in the zone).
 @constant ISGeofenceEventTypeEntered After a custom time and if the state didn't changed, we consider that a position is entered.
 @constant ISGeofenceEventTypeStay After a position was entered in a zone and after a custom time without state change, we consider that a position stayed in the zone.
 @constant ISGeofenceEventTypeLeaving A position is leaving a zone. (a position was detected outside the zone).
 @constant ISGeofenceEventTypeLeft After a position was considerer leaving and if no state change occured for a custom time, we consider that a position has left the zone.
 */
typedef enum {
    ISEGeofenceEventTypeUnknown = 0,
    ISEGeofenceEventTypeEntering,
    ISEGeofenceEventTypeEntered,    //2
    ISEGeofenceEventTypeStay,       //3
    ISEGeofenceEventTypeLeaving,
    ISEGeofenceEventTypeLeft        //5
} ISEGeofenceEventType;
